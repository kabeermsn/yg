CONTENTS OF THIS FILE
---------------------

 * Introduction
 * Installation
 * Maintainers

 INTRODUCTION
 ------------

 The Twig Blocks module adds a twig function to render a block in twig by
 the block ID.

 INSTALLATION
 ------------

  * Install as you would normally install a contributed Drupal module. See:
    https://drupal.org/documentation/install/modules-themes/modules-8
    for further information.

 MAINTAINERS
 -----------

 Current maintainers:
  * Adam (hook_awesome) - https://www.drupal.org/user/2802921
