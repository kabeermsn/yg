<?php

/**
 * @file
 * Post update functions for Editor.
 */

/**
 * Clear the render cache to fix file references added by Editor.
 */
function editor_post_update_clear_cache_for_file_reference_filter() {
}
