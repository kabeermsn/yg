<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/yg_construction/templates/page.html.twig */
class __TwigTemplate_3171657b7c0dbb3d4a0990992a0270f70914df36305999cfc8f682a6ddec6122 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
            'main' => [$this, 'block_main'],
            'sidebar_first' => [$this, 'block_sidebar_first'],
            'highlighted' => [$this, 'block_highlighted'],
            'breadcrumb' => [$this, 'block_breadcrumb'],
            'action_links' => [$this, 'block_action_links'],
            'help' => [$this, 'block_help'],
            'content' => [$this, 'block_content'],
            'sidebar_second' => [$this, 'block_sidebar_second'],
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $tags = ["if" => 63, "block" => 120, "set" => 134];
        $filters = ["escape" => 76];
        $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['if', 'block', 'set'],
                ['escape'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 59
        echo "
<body id=\"page-top\" data-spy=\"scroll\" data-target=\".navbar-fixed-top\">

<!-- Menu Section -->
";
        // line 63
        if (($context["header_lite"] ?? null)) {
            // line 64
            echo "<header id=\"header\" class=\"white-header\" >
";
        } else {
            // line 66
            echo "<header id=\"header\"  >
";
        }
        // line 68
        echo "
 
  <div class=\"header-top-right\">
  <div class=\"container\">
      <div class=\"col-md-8 col-sm-12 col-xs-12 ml-auto\">
        <div class=\"interior-nav\">
         <div class=\"social\">
          <ul>
            <li><a href=\"";
        // line 76
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["facebook"] ?? null)), "html", null, true);
        echo "\"><i class=\"fa fa-facebook-f\"></i></a></li>
            <li><a href=\"";
        // line 77
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["google"] ?? null)), "html", null, true);
        echo "\"><i class=\"fa fa-google-plus\"></i></a></li>
            <li><a href=\"";
        // line 78
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["instagram"] ?? null)), "html", null, true);
        echo "\"><i class=\"fa fa-instagram\"></i></a></li>
            <li><a href=\"";
        // line 79
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["twitter"] ?? null)), "html", null, true);
        echo "\"><i class=\"fa fa-twitter\" aria-hidden=\"true\"></i></a></li>
          </ul>
          </div>
          <div class=\"phone\">
            <p> <span> ";
        // line 83
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["phone_label"] ?? null)), "html", null, true);
        echo "</span><a href=\"tel:";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["phone"] ?? null)), "html", null, true);
        echo "\"> ";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["phone"] ?? null)), "html", null, true);
        echo "</a></p>
          </div>                  
        </div>  
      </div> 
  </div>
  </div> 
   ";
        // line 89
        if (($this->getAttribute(($context["page"] ?? null), "navigation", []) || $this->getAttribute(($context["page"] ?? null), "primary_menu", []))) {
            // line 90
            echo "    ";
            if ($this->getAttribute(($context["page"] ?? null), "navigation", [])) {
                // line 91
                echo "  
  <nav class=\"navbar navbar-expand-lg navbar-light navbar-fixed-top\" id=\"mainNav\">
    <div class=\"container\">    
       ";
                // line 94
                echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "logo", [])), "html", null, true);
                echo "
      <button class=\"navbar-toggler navbar-toggler-right\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarResponsive\"  aria-controls=\"navbarResponsive\" aria-expanded=\"false\" aria-label=\"Toggle navigation\"> <i class=\"fa fa-bars\"></i> </button>
      <div class=\"collapse navbar-collapse\" id=\"navbarResponsive\">
        ";
                // line 97
                echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "navigation", [])), "html", null, true);
                echo "
      </div>
    </div>
    </nav> 

</header>
 ";
            }
            // line 103
            echo "  
";
        }
        // line 105
        echo "
";
        // line 106
        if ($this->getAttribute(($context["page"] ?? null), "title", [])) {
            // line 107
            echo "    <div class=\"page-header\">
     <div class=\"container\">
        <div id=\"page-title\">
           ";
            // line 110
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "title", [])), "html", null, true);
            echo "
        </div>
      </div>
    </div>
";
        }
        // line 115
        echo "

          ";
        // line 117
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "slider", [])), "html", null, true);
        echo "

";
        // line 120
        $this->displayBlock('main', $context, $blocks);
        // line 189
        echo "
<!-- FOOTER SECTION-->
<section id=\"footer\">
  <div class=\"container\">
    <div class=\"row\">
      <div class=\"col-md-3 col-sm-12 footer-columns footer-columns-1 wow fadeInLeft\" data-wow-delay=\"0.3s\">
        ";
        // line 195
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "footer_col_1", [])), "html", null, true);
        echo "
      </div>
      <div class=\"col-md-3 col-sm-12 footer-columns wow fadeInUp\" data-wow-delay=\"0.6s\">
        
        ";
        // line 199
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "footer_col_2", [])), "html", null, true);
        echo "
      </div>
      <div class=\"col-md-3 col-sm-12 footer-columns wow fadeInDown\" data-wow-delay=\"0.9s\">
        <h6>";
        // line 202
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["lets_talk"] ?? null)), "html", null, true);
        echo "</h6>
        <p><a href=\"tel:";
        // line 203
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["phone"] ?? null)), "html", null, true);
        echo "\">";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["phone"] ?? null)), "html", null, true);
        echo "</a></p>
        <p><a href=\"mailto:";
        // line 204
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["email"] ?? null)), "html", null, true);
        echo "\">";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["email"] ?? null)), "html", null, true);
        echo "</a></p>
      </div>
      <div class=\"col-md-3 col-sm-12 footer-columns wow fadeInRight\" data-wow-delay=\"0.9s\">
        <h6>";
        // line 207
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["follow_us"] ?? null)), "html", null, true);
        echo "</h6>
        <div class=\"social\">
          <ul>
            <li><a href=\"";
        // line 210
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["linkedin"] ?? null)), "html", null, true);
        echo "\"><i class=\"fa fa-linkedin\"></i></a></li>
            <li><a href=\"";
        // line 211
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["instagram"] ?? null)), "html", null, true);
        echo "\"><i class=\"fa fa-instagram\"></i></a></li>
            <li><a href=\"";
        // line 212
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["facebook"] ?? null)), "html", null, true);
        echo "\"><i class=\"fa fa-facebook-f\"></i></a></li>
            <li><a href=\"";
        // line 213
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["twitter"] ?? null)), "html", null, true);
        echo "\"><i class=\"fa fa-twitter\" aria-hidden=\"true\"></i></a></li>
            <li><a href=\"";
        // line 214
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["google"] ?? null)), "html", null, true);
        echo "\"><i class=\"fa fa-google-plus\"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- copyright -->

<section id=\"copyright\">
  <div class=\"container\">
    <div class=\"row\">  
      <div class=\"col-md-6 mx-auto text-center fadeInRight animated\" data-wow-delay=\"0.3s\"> 
        <p>© 2018 <span>YG Construction</span>. All Rights Reserved. </p>
        <p>Theme By<a href=\"https://www.drupaldevelopersstudio.com/\" target=\"_blank\"> Drupal Developers Studio</a>, A Division of <a href=\"https://www.youngglobes.com/\" target=\"_blank\">Young Globes</a></p>  
      </div>
    </div>
  </div>
</section>
</body>";
    }

    // line 120
    public function block_main($context, array $blocks = [])
    {
        // line 121
        echo "  <div role=\"main\" class=\"blog-container js-quickedit-main-content\">
    
      ";
        // line 124
        echo "      ";
        if ($this->getAttribute(($context["page"] ?? null), "sidebar_first", [])) {
            // line 125
            echo "        ";
            $this->displayBlock('sidebar_first', $context, $blocks);
            // line 130
            echo "      ";
        }
        // line 131
        echo "
      ";
        // line 133
        echo "      ";
        // line 134
        $context["content_classes"] = [0 => ((($this->getAttribute(        // line 135
($context["page"] ?? null), "sidebar_first", []) && $this->getAttribute(($context["page"] ?? null), "sidebar_second", []))) ? ("col-sm-6") : ("")), 1 => ((($this->getAttribute(        // line 136
($context["page"] ?? null), "sidebar_first", []) && twig_test_empty($this->getAttribute(($context["page"] ?? null), "sidebar_second", [])))) ? ("col-sm-9") : ("")), 2 => ((($this->getAttribute(        // line 137
($context["page"] ?? null), "sidebar_second", []) && twig_test_empty($this->getAttribute(($context["page"] ?? null), "sidebar_first", [])))) ? ("col-sm-9") : ("")), 3 => (((twig_test_empty($this->getAttribute(        // line 138
($context["page"] ?? null), "sidebar_first", [])) && twig_test_empty($this->getAttribute(($context["page"] ?? null), "sidebar_second", [])))) ? ("") : (""))];
        // line 141
        echo "      <section class=\"main-content-region-1\" ";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["content_attributes"] ?? null), "addClass", [0 => ($context["content_classes"] ?? null)], "method")), "html", null, true);
        echo ">

        ";
        // line 144
        echo "        ";
        if ($this->getAttribute(($context["page"] ?? null), "highlighted", [])) {
            // line 145
            echo "          ";
            $this->displayBlock('highlighted', $context, $blocks);
            // line 148
            echo "        ";
        }
        // line 149
        echo "
        ";
        // line 151
        echo "        ";
        if (($context["breadcrumb"] ?? null)) {
            // line 152
            echo "          ";
            $this->displayBlock('breadcrumb', $context, $blocks);
            // line 155
            echo "        ";
        }
        // line 156
        echo "
        ";
        // line 158
        echo "        ";
        if (($context["action_links"] ?? null)) {
            // line 159
            echo "          ";
            $this->displayBlock('action_links', $context, $blocks);
            // line 162
            echo "        ";
        }
        // line 163
        echo "
        ";
        // line 165
        echo "        ";
        if ($this->getAttribute(($context["page"] ?? null), "help", [])) {
            // line 166
            echo "          ";
            $this->displayBlock('help', $context, $blocks);
            // line 169
            echo "        ";
        }
        // line 170
        echo "
        ";
        // line 172
        echo "        ";
        $this->displayBlock('content', $context, $blocks);
        // line 176
        echo "      </section>

      ";
        // line 179
        echo "      ";
        if ($this->getAttribute(($context["page"] ?? null), "sidebar_second", [])) {
            // line 180
            echo "        ";
            $this->displayBlock('sidebar_second', $context, $blocks);
            // line 185
            echo "      ";
        }
        // line 186
        echo "  
   </div>
";
    }

    // line 125
    public function block_sidebar_first($context, array $blocks = [])
    {
        // line 126
        echo "          <aside class=\"col-sm-3\" role=\"complementary\">
            ";
        // line 127
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "sidebar_first", [])), "html", null, true);
        echo "
          </aside>
        ";
    }

    // line 145
    public function block_highlighted($context, array $blocks = [])
    {
        // line 146
        echo "            <div class=\"highlighted\">";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "highlighted", [])), "html", null, true);
        echo "</div>
          ";
    }

    // line 152
    public function block_breadcrumb($context, array $blocks = [])
    {
        // line 153
        echo "            ";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["breadcrumb"] ?? null)), "html", null, true);
        echo "
          ";
    }

    // line 159
    public function block_action_links($context, array $blocks = [])
    {
        // line 160
        echo "            <ul class=\"action-links\">";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["action_links"] ?? null)), "html", null, true);
        echo "</ul>
          ";
    }

    // line 166
    public function block_help($context, array $blocks = [])
    {
        // line 167
        echo "            ";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "help", [])), "html", null, true);
        echo "
          ";
    }

    // line 172
    public function block_content($context, array $blocks = [])
    {
        // line 173
        echo "          <a id=\"main-content\"></a>
          ";
        // line 174
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "content", [])), "html", null, true);
        echo "
        ";
    }

    // line 180
    public function block_sidebar_second($context, array $blocks = [])
    {
        // line 181
        echo "          <aside class=\"col-sm-3\" role=\"complementary\">
            ";
        // line 182
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "sidebar_second", [])), "html", null, true);
        echo "
          </aside>
        ";
    }

    public function getTemplateName()
    {
        return "themes/yg_construction/templates/page.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  440 => 182,  437 => 181,  434 => 180,  428 => 174,  425 => 173,  422 => 172,  415 => 167,  412 => 166,  405 => 160,  402 => 159,  395 => 153,  392 => 152,  385 => 146,  382 => 145,  375 => 127,  372 => 126,  369 => 125,  363 => 186,  360 => 185,  357 => 180,  354 => 179,  350 => 176,  347 => 172,  344 => 170,  341 => 169,  338 => 166,  335 => 165,  332 => 163,  329 => 162,  326 => 159,  323 => 158,  320 => 156,  317 => 155,  314 => 152,  311 => 151,  308 => 149,  305 => 148,  302 => 145,  299 => 144,  293 => 141,  291 => 138,  290 => 137,  289 => 136,  288 => 135,  287 => 134,  285 => 133,  282 => 131,  279 => 130,  276 => 125,  273 => 124,  269 => 121,  266 => 120,  241 => 214,  237 => 213,  233 => 212,  229 => 211,  225 => 210,  219 => 207,  211 => 204,  205 => 203,  201 => 202,  195 => 199,  188 => 195,  180 => 189,  178 => 120,  173 => 117,  169 => 115,  161 => 110,  156 => 107,  154 => 106,  151 => 105,  147 => 103,  137 => 97,  131 => 94,  126 => 91,  123 => 90,  121 => 89,  108 => 83,  101 => 79,  97 => 78,  93 => 77,  89 => 76,  79 => 68,  75 => 66,  71 => 64,  69 => 63,  63 => 59,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "themes/yg_construction/templates/page.html.twig", "/var/www/html/yg_construction/themes/yg_construction/templates/page.html.twig");
    }
}
