<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/yg_construction/templates/page--front.html.twig */
class __TwigTemplate_30076f8d38d463a4bc18bc1dbcffbbe05423ae6fab884c3b05c6fdf072d5f0b4 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
            'main' => [$this, 'block_main'],
            'sidebar_first' => [$this, 'block_sidebar_first'],
            'highlighted' => [$this, 'block_highlighted'],
            'breadcrumb' => [$this, 'block_breadcrumb'],
            'action_links' => [$this, 'block_action_links'],
            'help' => [$this, 'block_help'],
            'content' => [$this, 'block_content'],
            'sidebar_second' => [$this, 'block_sidebar_second'],
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $tags = ["if" => 63, "block" => 119, "set" => 133];
        $filters = ["escape" => 75];
        $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['if', 'block', 'set'],
                ['escape'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 59
        echo "
<body id=\"page-top\" data-spy=\"scroll\" data-target=\".navbar-fixed-top\">

<!-- Menu Section -->
";
        // line 63
        if (($context["header_lite"] ?? null)) {
            // line 64
            echo "<header id=\"header\" class=\"white-header\" >
";
        } else {
            // line 66
            echo "<header id=\"header\"  >
";
        }
        // line 68
        echo " 
  <div class=\"header-top-right\">
  <div class=\"container\">
      <div class=\"col-md-8 col-sm-12 col-xs-12 ml-auto\">
        <div class=\"interior-nav\">
         <div class=\"social\">
          <ul>
            <li><a href=\"";
        // line 75
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["facebook"] ?? null)), "html", null, true);
        echo "\"><i class=\"fa fa-facebook-f\"></i></a></li>
            <li><a href=\"";
        // line 76
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["google"] ?? null)), "html", null, true);
        echo "\"><i class=\"fa fa-google-plus\"></i></a></li>
            <li><a href=\"";
        // line 77
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["instagram"] ?? null)), "html", null, true);
        echo "\"><i class=\"fa fa-instagram\"></i></a></li>
            <li><a href=\"";
        // line 78
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["twitter"] ?? null)), "html", null, true);
        echo "\"><i class=\"fa fa-twitter\" aria-hidden=\"true\"></i></a></li>
          </ul>
          </div>
          <div class=\"phone\">
            <p> <span> ";
        // line 82
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["phone_label"] ?? null)), "html", null, true);
        echo "</span><a href=\"tel:";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["phone"] ?? null)), "html", null, true);
        echo "\"> ";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["phone"] ?? null)), "html", null, true);
        echo "</a></p>
          </div>                  
        </div>  
      </div> 
  </div>
  </div> 
   ";
        // line 88
        if (($this->getAttribute(($context["page"] ?? null), "navigation", []) || $this->getAttribute(($context["page"] ?? null), "primary_menu", []))) {
            // line 89
            echo "    ";
            if ($this->getAttribute(($context["page"] ?? null), "navigation", [])) {
                // line 90
                echo "  
  <nav class=\"navbar navbar-expand-lg navbar-light navbar-fixed-top\" id=\"mainNav\">
    <div class=\"container\">
       ";
                // line 93
                echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "logo", [])), "html", null, true);
                echo "
      <button class=\"navbar-toggler navbar-toggler-right\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarResponsive\"  aria-controls=\"navbarResponsive\" aria-expanded=\"false\" aria-label=\"Toggle navigation\"> <i class=\"fa fa-bars\"></i> </button>
      <div class=\"collapse navbar-collapse\" id=\"navbarResponsive\">
        ";
                // line 96
                echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "navigation", [])), "html", null, true);
                echo "
      </div>
    </div>
    </nav> 

</header>
 ";
            }
            // line 102
            echo "  
";
        }
        // line 104
        echo "
";
        // line 105
        if ($this->getAttribute(($context["page"] ?? null), "title", [])) {
            // line 106
            echo "    <div class=\"page-header\">
     <div class=\"container\">
        <div id=\"page-title\">
           ";
            // line 109
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "title", [])), "html", null, true);
            echo "
        </div>
      </div>
    </div>
";
        }
        // line 114
        echo "

          ";
        // line 116
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "slider", [])), "html", null, true);
        echo "

";
        // line 119
        $this->displayBlock('main', $context, $blocks);
        // line 188
        echo "
<!-- FOOTER SECTION-->
<section id=\"footer\">
  <div class=\"container\">
    <div class=\"row\">
      <div class=\"col-md-3 col-sm-12 footer-columns footer-columns-1 wow fadeInLeft\" data-wow-delay=\"0.3s\">
        ";
        // line 194
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "footer_col_1", [])), "html", null, true);
        echo "
      </div>
      <div class=\"col-md-3 col-sm-12 footer-columns wow fadeInUp\" data-wow-delay=\"0.6s\">
        
        ";
        // line 198
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "footer_col_2", [])), "html", null, true);
        echo "
      </div>
      <div class=\"col-md-3 col-sm-12 footer-columns wow fadeInDown\" data-wow-delay=\"0.9s\">
        <h6>";
        // line 201
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["lets_talk"] ?? null)), "html", null, true);
        echo "</h6>
        <p><a href=\"tel:";
        // line 202
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["phone"] ?? null)), "html", null, true);
        echo "\">";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["phone"] ?? null)), "html", null, true);
        echo "</a></p>
        <p><a href=\"mailto:";
        // line 203
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["email"] ?? null)), "html", null, true);
        echo "\">";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["email"] ?? null)), "html", null, true);
        echo "</a></p>
      </div>
      <div class=\"col-md-3 col-sm-12 footer-columns wow fadeInRight\" data-wow-delay=\"0.9s\">
        <h6>";
        // line 206
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["follow_us"] ?? null)), "html", null, true);
        echo "</h6>
        <div class=\"social\">
          <ul>
            <li><a href=\"";
        // line 209
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["linkedin"] ?? null)), "html", null, true);
        echo "\"><i class=\"fa fa-linkedin\"></i></a></li>
            <li><a href=\"";
        // line 210
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["instagram"] ?? null)), "html", null, true);
        echo "\"><i class=\"fa fa-instagram\"></i></a></li>
            <li><a href=\"";
        // line 211
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["facebook"] ?? null)), "html", null, true);
        echo "\"><i class=\"fa fa-facebook-f\"></i></a></li>
            <li><a href=\"";
        // line 212
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["twitter"] ?? null)), "html", null, true);
        echo "\"><i class=\"fa fa-twitter\" aria-hidden=\"true\"></i></a></li>
            <li><a href=\"";
        // line 213
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["google"] ?? null)), "html", null, true);
        echo "\"><i class=\"fa fa-google-plus\"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- copyright -->

<section id=\"copyright\">
  <div class=\"container\">
    <div class=\"row\">  
      <div class=\"col-md-6 mx-auto text-center fadeInRight animated\" data-wow-delay=\"0.3s\"> 
        <p>© 2018 <span>YG Construction</span>. All Rights Reserved. </p>
        <p>Theme By<a href=\"https://www.drupaldevelopersstudio.com/\" target=\"_blank\"> Drupal Developers Studio</a>, A Division of <a href=\"https://www.youngglobes.com/\" target=\"_blank\">Young Globes</a></p>  
      </div>
    </div>
  </div>
</section>
</body>";
    }

    // line 119
    public function block_main($context, array $blocks = [])
    {
        // line 120
        echo "  <div role=\"main\" class=\"blog-container js-quickedit-main-content\">
    
      ";
        // line 123
        echo "      ";
        if ($this->getAttribute(($context["page"] ?? null), "sidebar_first", [])) {
            // line 124
            echo "        ";
            $this->displayBlock('sidebar_first', $context, $blocks);
            // line 129
            echo "      ";
        }
        // line 130
        echo "
      ";
        // line 132
        echo "      ";
        // line 133
        $context["content_classes"] = [0 => ((($this->getAttribute(        // line 134
($context["page"] ?? null), "sidebar_first", []) && $this->getAttribute(($context["page"] ?? null), "sidebar_second", []))) ? ("col-sm-6") : ("")), 1 => ((($this->getAttribute(        // line 135
($context["page"] ?? null), "sidebar_first", []) && twig_test_empty($this->getAttribute(($context["page"] ?? null), "sidebar_second", [])))) ? ("col-sm-9") : ("")), 2 => ((($this->getAttribute(        // line 136
($context["page"] ?? null), "sidebar_second", []) && twig_test_empty($this->getAttribute(($context["page"] ?? null), "sidebar_first", [])))) ? ("col-sm-9") : ("")), 3 => (((twig_test_empty($this->getAttribute(        // line 137
($context["page"] ?? null), "sidebar_first", [])) && twig_test_empty($this->getAttribute(($context["page"] ?? null), "sidebar_second", [])))) ? ("") : (""))];
        // line 140
        echo "      <section class=\"main-content-region-1\" ";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["content_attributes"] ?? null), "addClass", [0 => ($context["content_classes"] ?? null)], "method")), "html", null, true);
        echo ">

        ";
        // line 143
        echo "        ";
        if ($this->getAttribute(($context["page"] ?? null), "highlighted", [])) {
            // line 144
            echo "          ";
            $this->displayBlock('highlighted', $context, $blocks);
            // line 147
            echo "        ";
        }
        // line 148
        echo "
        ";
        // line 150
        echo "        ";
        if (($context["breadcrumb"] ?? null)) {
            // line 151
            echo "          ";
            $this->displayBlock('breadcrumb', $context, $blocks);
            // line 154
            echo "        ";
        }
        // line 155
        echo "
        ";
        // line 157
        echo "        ";
        if (($context["action_links"] ?? null)) {
            // line 158
            echo "          ";
            $this->displayBlock('action_links', $context, $blocks);
            // line 161
            echo "        ";
        }
        // line 162
        echo "
        ";
        // line 164
        echo "        ";
        if ($this->getAttribute(($context["page"] ?? null), "help", [])) {
            // line 165
            echo "          ";
            $this->displayBlock('help', $context, $blocks);
            // line 168
            echo "        ";
        }
        // line 169
        echo "
        ";
        // line 171
        echo "        ";
        $this->displayBlock('content', $context, $blocks);
        // line 175
        echo "      </section>

      ";
        // line 178
        echo "      ";
        if ($this->getAttribute(($context["page"] ?? null), "sidebar_second", [])) {
            // line 179
            echo "        ";
            $this->displayBlock('sidebar_second', $context, $blocks);
            // line 184
            echo "      ";
        }
        // line 185
        echo "  
   </div>
";
    }

    // line 124
    public function block_sidebar_first($context, array $blocks = [])
    {
        // line 125
        echo "          <aside class=\"col-sm-3\" role=\"complementary\">
            ";
        // line 126
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "sidebar_first", [])), "html", null, true);
        echo "
          </aside>
        ";
    }

    // line 144
    public function block_highlighted($context, array $blocks = [])
    {
        // line 145
        echo "            <div class=\"highlighted\">";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "highlighted", [])), "html", null, true);
        echo "</div>
          ";
    }

    // line 151
    public function block_breadcrumb($context, array $blocks = [])
    {
        // line 152
        echo "            ";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["breadcrumb"] ?? null)), "html", null, true);
        echo "
          ";
    }

    // line 158
    public function block_action_links($context, array $blocks = [])
    {
        // line 159
        echo "            <ul class=\"action-links\">";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["action_links"] ?? null)), "html", null, true);
        echo "</ul>
          ";
    }

    // line 165
    public function block_help($context, array $blocks = [])
    {
        // line 166
        echo "            ";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "help", [])), "html", null, true);
        echo "
          ";
    }

    // line 171
    public function block_content($context, array $blocks = [])
    {
        // line 172
        echo "          <a id=\"main-content\"></a>
          ";
        // line 173
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "content", [])), "html", null, true);
        echo "
        ";
    }

    // line 179
    public function block_sidebar_second($context, array $blocks = [])
    {
        // line 180
        echo "          <aside class=\"col-sm-3\" role=\"complementary\">
            ";
        // line 181
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "sidebar_second", [])), "html", null, true);
        echo "
          </aside>
        ";
    }

    public function getTemplateName()
    {
        return "themes/yg_construction/templates/page--front.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  439 => 181,  436 => 180,  433 => 179,  427 => 173,  424 => 172,  421 => 171,  414 => 166,  411 => 165,  404 => 159,  401 => 158,  394 => 152,  391 => 151,  384 => 145,  381 => 144,  374 => 126,  371 => 125,  368 => 124,  362 => 185,  359 => 184,  356 => 179,  353 => 178,  349 => 175,  346 => 171,  343 => 169,  340 => 168,  337 => 165,  334 => 164,  331 => 162,  328 => 161,  325 => 158,  322 => 157,  319 => 155,  316 => 154,  313 => 151,  310 => 150,  307 => 148,  304 => 147,  301 => 144,  298 => 143,  292 => 140,  290 => 137,  289 => 136,  288 => 135,  287 => 134,  286 => 133,  284 => 132,  281 => 130,  278 => 129,  275 => 124,  272 => 123,  268 => 120,  265 => 119,  240 => 213,  236 => 212,  232 => 211,  228 => 210,  224 => 209,  218 => 206,  210 => 203,  204 => 202,  200 => 201,  194 => 198,  187 => 194,  179 => 188,  177 => 119,  172 => 116,  168 => 114,  160 => 109,  155 => 106,  153 => 105,  150 => 104,  146 => 102,  136 => 96,  130 => 93,  125 => 90,  122 => 89,  120 => 88,  107 => 82,  100 => 78,  96 => 77,  92 => 76,  88 => 75,  79 => 68,  75 => 66,  71 => 64,  69 => 63,  63 => 59,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "themes/yg_construction/templates/page--front.html.twig", "/var/www/html/yg_construction/themes/yg_construction/templates/page--front.html.twig");
    }
}
