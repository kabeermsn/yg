<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/yg_construction/templates/views/views-view--home_slider--block.html.twig */
class __TwigTemplate_6db00dc449f658819594afe8196868d9a8283080fd91dfe8a5d5a8b6d85cae37 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $tags = ["for" => 5, "if" => 6];
        $filters = ["escape" => 6, "image_style" => 11];
        $functions = ["file_url" => 11];

        try {
            $this->sandbox->checkSecurity(
                ['for', 'if'],
                ['escape', 'image_style'],
                ['file_url']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "
<section id=\"yg-slider\">
<div id=\"carouselYGHotel\" class=\"carousel slide\" data-ride=\"carousel\">
       <ol class=\"carousel-indicators\">
       ";
        // line 5
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["view"] ?? null), "result", []));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["result"]) {
            // line 6
            echo "         <li data-target=\"#carouselYGHotel\" data-slide-to=\"";
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($this->getAttribute($context["loop"], "index", []) - 1), "html", null, true);
            echo "\" class=\"";
            if (($this->getAttribute($context["loop"], "index", []) == 1)) {
                echo "active";
            }
            echo "\"></li>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['result'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 7
        echo "         
       </ol>
       <div class=\"carousel-inner\" role=\"listbox\">
       ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["view"] ?? null), "result", []));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["result"]) {
            // line 11
            echo "         <div class=\"carousel-item ";
            if (($this->getAttribute($context["loop"], "index", []) == 1)) {
                echo "active";
            }
            echo "\" style=\"background-image: url('";
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, call_user_func_array($this->env->getFunction('file_url')->getCallable(), [$this->env->getExtension('Drupal\twig_tweak\TwigExtension')->imageStyle($this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute($this->getAttribute(($context["view"] ?? null), "field", []), "uri", []), "value", [0 => $this->getAttribute($this->getAttribute(($context["view"] ?? null), "result", []), ($this->getAttribute($context["loop"], "index", []) - 1), [], "array")], "method")), "slider")]), "html", null, true);
            echo "')\">
          <div class=\"carousel-caption wow fadeInDown\">
          <h3>";
            // line 13
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute($this->getAttribute(($context["view"] ?? null), "field", []), "field_subtitle", []), "value", [0 => $this->getAttribute($this->getAttribute(($context["view"] ?? null), "result", []), ($this->getAttribute($context["loop"], "index", []) - 1), [], "array")], "method")), "html", null, true);
            echo "</h3>
          <h2>";
            // line 14
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute($this->getAttribute(($context["view"] ?? null), "field", []), "title", []), "value", [0 => $this->getAttribute($this->getAttribute(($context["view"] ?? null), "result", []), ($this->getAttribute($context["loop"], "index", []) - 1), [], "array")], "method")), "html", null, true);
            echo "</h2>
          <p>";
            // line 15
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute($this->getAttribute(($context["view"] ?? null), "field", []), "field_description", []), "value", [0 => $this->getAttribute($this->getAttribute(($context["view"] ?? null), "result", []), ($this->getAttribute($context["loop"], "index", []) - 1), [], "array")], "method")), "html", null, true);
            echo "</p>
          ";
            // line 18
            echo "          </div>
         </div>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['result'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 20
        echo " 
       </div>
     </div>
</div>
</section>
<!-- END BANNER SLIDER SECTION -->
";
    }

    public function getTemplateName()
    {
        return "themes/yg_construction/templates/views/views-view--home_slider--block.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  159 => 20,  143 => 18,  139 => 15,  135 => 14,  131 => 13,  121 => 11,  104 => 10,  99 => 7,  78 => 6,  61 => 5,  55 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "themes/yg_construction/templates/views/views-view--home_slider--block.html.twig", "/var/www/html/yg_construction/themes/yg_construction/templates/views/views-view--home_slider--block.html.twig");
    }
}
